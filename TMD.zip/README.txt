===========================================================================
Title                   : Trench Marine Doom
Filename                : TrenchMarineDoom.WAD
Advanced engine needed  : Eternity, ZDoom sourceports, etc.
Primary purpose         : Single+Coop play only
Author                  : papasrod
Misc. Author Info       : Hobbyist/Newbie Programmer

Description             : This is an edited map of Marine1.wad by Sergeant Daniel G. Snyder, USMC
                        : The aim of this edited wad is to bring out the map's potential wide and open space into an actual hectic battlefield
                        : Using only simple Dehacked gimmicks and Eternity's advanced bits 2 & 3

Additional Credits to   : MegaZombieman115 MAP01, Sergeant Daniel G. Snyder MAP02 
===========================================================================

* Information *

Game                    : DOOM 2
Map #                   : Map01, Map02
Single Player           : Yes
Cooperative 2-4 Player  : Yes
Deathmatch 2-4 Player   : No
Difficulty Settings     : Not implemented
New Sounds              : No
New Graphics            : Yes
New Music               : Yes
Dehacked/BEX Patch      : Yes
Demos Replaced          : None
Other Files             : TrenchMarineDoom(alwaysrespawnmonsters) This is a separate wad, load this one instead if you want a quasi-nightmare mode game. - Sit back and watch your army of friendly marines do the work!

* Construction *

Base                    : Modified Marine1.WAD
Build Time              : 2 weeks
Editor(s) used          : UDB
Known Bugs              : None (so far :P)
May Not Run With        : 


* Copyright / Permissions *

Authors may use this level as a base to build additional
levels.  

(One of the following)

You MAY distribute this WAD, provided you include this file, with
no modifications.  You may distribute this file in any electronic
format (BBS, Diskette, CD, etc) as long as you include this file 
intact.

You MAY not distribute this WAD file in any format.

You may do whatever you want with this file.


* Where to get this WAD *

Link to original WAD : https://www.moddb.com/mods/world-war-doom/downloads/world-war-doom
                       https://www.doomworld.com/idgames/themes/marines/marine1